package com.cognizant.service;

import com.cognizant.model.Registration;

public interface RegistrationService {
	public boolean insertUser(Registration reg);

}
